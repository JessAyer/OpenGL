/*-------------------------------------------------
* Author: Jessica Ayer
* SNHU CS 330: Computer Graphics and Visualization
* Instructor: Kurt Diesch
* Date: Augst 14, 2022
---------------------------------------------------
*/

#define STB_IMAGE_IMPLEMENTATION

#include <stdio.h>
#include <string.h>
#include <cmath>
#include <vector>

#include <GL\glew.h>
#include <GLFW\glfw3.h>

#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>

#include "CommonValues.h"

#include "GLwindow.h"
#include "Mesh.h"
#include "Shader.h"
#include "Camera.h"
#include "Texture.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "Material.h"
#include "Sphere.h"
#include "SolidSphere.h"


const float toRadians = 3.14159265f / 180.0f;

GLwindow mainWindow;
std::vector<Mesh*> meshList;
std::vector<Shader> shaderList;
Camera camera;

//Window
GLint windowWidth = 1600;
GLint windowHeight = 1200;

//Textures
Texture redGlassTexture;
Texture floorTexture;
Texture candleTexture;
Texture redTexture;
Texture rainbowTexture;
Texture plainTexture;
Texture pyramidTexture;

//Materials
Material shinyMaterial;
Material dullMaterial;

//Lights
DirectionalLight mainLight;
PointLight pointLights[MAX_POINT_LIGHTS];
SpotLight spotLights[MAX_SPOT_LIGHTS];

//Time
GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;

// sphere
Sphere sphere(1.0, 300, 300, true);
//SolidSphere sphere(1, 400, 800);

// Vertex Shader
static const char* vShader = "Shaders/shader.vert";

// Fragment Shader
static const char* fShader = "Shaders/shader.frag";

/* -------------------------------------------------------------------------------------------------------------
 *                                      Calculate Average Normals
 * -------------------------------------------------------------------------------------------------------------
 */
void calcAverageNormals(unsigned int* indices, unsigned int indiceCount, GLfloat* vertices, unsigned int verticeCount,
	unsigned int vLength, unsigned int normalOffset)
{
	for (size_t i = 0; i < indiceCount; i += 3)
	{
		unsigned int in0 = indices[i] * vLength;
		unsigned int in1 = indices[i + 1] * vLength;
		unsigned int in2 = indices[i + 2] * vLength;
		glm::vec3 v1(vertices[in1] - vertices[in0], vertices[in1 + 1] - vertices[in0 + 1], vertices[in1 + 2] - vertices[in0 + 2]);
		glm::vec3 v2(vertices[in2] - vertices[in0], vertices[in2 + 1] - vertices[in0 + 1], vertices[in2 + 2] - vertices[in0 + 2]);
		glm::vec3 normal = glm::cross(v1, v2);
		normal = glm::normalize(normal);

		in0 += normalOffset; in1 += normalOffset; in2 += normalOffset;
		vertices[in0] += normal.x; vertices[in0 + 1] += normal.y; vertices[in0 + 2] += normal.z;
		vertices[in1] += normal.x; vertices[in1 + 1] += normal.y; vertices[in1 + 2] += normal.z;
		vertices[in2] += normal.x; vertices[in2 + 1] += normal.y; vertices[in2 + 2] += normal.z;
	}

	for (size_t i = 0; i < verticeCount / vLength; i++)
	{
		unsigned int nOffset = i * vLength + normalOffset;
		glm::vec3 vec(vertices[nOffset], vertices[nOffset + 1], vertices[nOffset + 2]);
		vec = glm::normalize(vec);
		vertices[nOffset] = vec.x; vertices[nOffset + 1] = vec.y; vertices[nOffset + 2] = vec.z;
	}
}

/* -------------------------------------------------------------------------------------------------------------
 *                                      Create Object
 * -------------------------------------------------------------------------------------------------------------
 */

void CreateObjects()
{
	unsigned int candleIndices[] = {
		0, 1, 2, // back 
		3, 2, 1,

		4, 5, 6, // front
		6, 7, 4,

		7, 2, 0, // left
		0, 4, 7,

		6, 3, 5,
		1, 5, 3, // right

		0, 1, 5, // bottom
		5, 4, 0
	};

	unsigned int cubeIndices[] = {
	0, 1, 2, // back 
	3, 2, 1,

	4, 5, 7, // front
	6, 7, 5,

	7, 2, 0, // left
	0, 4, 7,

	6, 3, 5,
	1, 5, 3, // right

	0, 1, 5, // bottom
	5, 4, 0,

	6, 3, 2, // top
	6, 2, 7,
	};

	GLfloat candleVertices[] = {
		//	 x      y      z			u	  v			nx	  ny    nz
			-1.0f,  0.0f, -1.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 0
			 1.0f,  0.0f, -1.0f,		1.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 1
			-1.0f,  1.0f, -1.0f,		0.0f, 1.0f,		0.0f, 0.0f, 0.0f, // 2		
			 1.0f,  1.0f, -1.0f,		1.0f, 1.0f,		0.0f, 0.0f, 0.0f, // 3
			-1.0f,  0.0f,  1.0f,	    0.0f, 1.0f,		0.0f, 0.0f, 0.0f, // 4
			 1.0f,  0.0f,  1.0f,	    1.0f, 1.0f,		0.0f, 0.0f, 0.0f, // 5
			 1.0f,  1.0f,  1.0f,	    0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 6
			-1.0f,  1.0f,  1.0f,		1.0f, 0.0f,		0.0f, 0.0f, 0.0f  // 7

	};
	
	unsigned int floorIndices[] = {
		0, 2, 1,
		1, 2, 3
	};

	GLfloat floorVertices[] = {
		   -10.0f, 0.0f, -10.0f,		0.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		    10.0f, 0.0f, -10.0f,		1.0f, 1.0f,		0.0f, -1.0f, 0.0f,
		   -10.0f, 0.0f,  10.0f,		0.0f, 0.0f,		0.0f, -1.0f, 0.0f,
		    10.0f, 0.0f,  10.0f,		1.0f, 0.0f,		0.0f, -1.0f, 0.0f,
	};

	unsigned int pyramidIndices[] = {
		0, 1, 2,	//front left
		0, 1, 3,	//front right
		0, 2, 4,	//back left
		0, 4, 3,	//back right
		1, 2, 3,	//base front
		2, 3, 4		// base back
	};

	GLfloat pyramidVertices[] = {
			0.0f,  1.0f,  0.0f,			0.5f, 1.0f,		0.0f, 0.0f, 0.0f, // 0	
			0.0f,  0.0f,  1.0f,         1.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 1	
		   -1.0f,  0.0f,  0.0f,         0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 2	
		    1.0f,  0.0f,  0.0f,         0.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 3	
			0.0f,  0.0f, -1.0f,         1.0f, 0.0f,		0.0f, 0.0f, 0.0f, // 4
	};


	calcAverageNormals(candleIndices, 30, candleVertices, 64, 8, 5);
	//candle holder base cube
	Mesh* obj1 = new Mesh();
	obj1->CreateMesh(candleVertices, candleIndices, 64, 30);
	meshList.push_back(obj1);

	//Candle holder top cube
	Mesh* obj2 = new Mesh();
	obj2->CreateMesh(candleVertices, candleIndices, 64, 30);
	meshList.push_back(obj2);

	// candle
	Mesh* obj3 = new Mesh();
	obj3->CreateMesh(floorVertices, floorIndices, 32, 6);
	meshList.push_back(obj3);
	
	//shere base
	Mesh* obj4 = new Mesh();
	obj4->CreateMesh(candleVertices, cubeIndices, 64, 36);
	meshList.push_back(obj4);

	//cube
	Mesh* obj5 = new Mesh();
	obj5->CreateMesh(candleVertices, cubeIndices, 64, 36);
	meshList.push_back(obj5);

	//floor
	Mesh* obj6 = new Mesh();
	obj6->CreateMesh(floorVertices, floorIndices, 32, 6);
	meshList.push_back(obj6);

	calcAverageNormals(pyramidIndices, 18, pyramidVertices, 40, 8, 5);

	//pyramid
	Mesh* obj7 = new Mesh();
	obj7->CreateMesh(pyramidVertices, pyramidIndices, 40, 18);
	meshList.push_back(obj7);

	//sphere
	Mesh* obj8 = new Mesh();
	obj8->CreateMesh(sphere.getVertices(), sphere.getIndices(), sphere.getVertexCount(), sphere.getIndexCount());
	meshList.push_back(obj8);
}

/* -------------------------------------------------------------------------------------------------------------
 *                                      Create Shader
 * -------------------------------------------------------------------------------------------------------------
 */
void CreateShaders()
{
	Shader* shader1 = new Shader();
	shader1->CreateFromFiles(vShader, fShader);
	shaderList.push_back(*shader1);
}

/* -------------------------------------------------------------------------------------------------------------
 *                                      Main
 * -------------------------------------------------------------------------------------------------------------
 */
int main(int argc, char* argv[])
{
	std::cout << "*****KEY CONTROLS FOR CAMERA MOVEMENT *****\n W = Forward\n S = Backwards\n A = Left\n D = Right\n" <<
		" Q = Up\n E = Down\n O = Ortho view\n P = Perspective view\n";
	std::cout << "\nUse the mouse scroll wheel to change the movement speed.\n\n";

	std::cout << sphere.getIndices();

	mainWindow = GLwindow(windowWidth, windowHeight);
	mainWindow.Initialize();

	CreateObjects();
	CreateShaders();

	camera = Camera(glm::vec3(0.0f, 0.0f, 20.0f), glm::vec3(0.0f, 1.0f, 0.0f), -90.0f, 0.0f, 5.0f, 0.5f);
	
	// Load Textures
	floorTexture = Texture("Textures/floor.png");
	floorTexture.LoadTexture();
	redGlassTexture = Texture("Textures/redGlass.png");
	redGlassTexture.LoadTexture();
	candleTexture = Texture("Textures/candle.png");
	candleTexture.LoadTexture();
	redTexture = Texture("Textures/red.png");
	redTexture.LoadTexture();
	rainbowTexture = Texture("Textures/rainbow.png");
	rainbowTexture.LoadTexture();
	plainTexture = Texture("Textures/plain.png");
	plainTexture.LoadTexture();
	pyramidTexture = Texture("Textures/pyramid.png");
	pyramidTexture.LoadTexture();

	//Materials
	shinyMaterial = Material(4.0f, 256);
	dullMaterial = Material(0.3f, 4);

	//Lights

	//Directional
	mainLight = DirectionalLight(1.0f, 1.0f, 0.5f,   //color
								 0.2f, 0.3f,		 //Intensity (ambient / directional)
								 0.0f, 0.0f, -1.0f); //direction

	// point
	unsigned int pointLightCount = 0;
	//candle holder
	pointLights[0] = PointLight(1.0f, 0.0f, 0.0f,	//color
								0.0f, 1.0f,			//Intensity (ambient/directional)
								6.0f, -1.5f, -4.0f,	//position
								0.3f, 0.2f, 0.1f);	//constant / linear/ exponent
	pointLightCount++;

	pointLights[1] = PointLight(1.0f, 0.0f, 0.0f,	//color
								0.0f, 1.0f,			//Intensity (ambient/directional)
								7.0f, 2.0f, -5.0f,	//position
								0.3f, 0.2f, 0.1f);	//constant / linear/ exponent
	pointLightCount++;

	//cube
	pointLights[2] = PointLight(1.0f, 1.0f, 1.0f,	//color
								1.5f, 0.3f,			//Intensity (ambient/directional)
								-2.0f,2.0f, 8.0f,	//position
								1.0f, 0.2f, 0.1f);	//constant / linear/ exponent
	pointLightCount++;

	//spot
	unsigned int spotLightCount = 0;
	//candle light
	spotLights[0] = SpotLight(1.0f,  1.0f,  0.0f,	//color
							  0.0f,  2.0f,			//Intensity (ambient/directional)
							  6.1f,  2.0f, -5.5f,	//position
						      0.0f, -1.0f,  0.5f,	//direction
						   	  1.0f,  0.0f,  0.0f,	//constant / linear / exponent
							  3.0f);				//edge
	spotLightCount++;
	//pyramid
	spotLights[1] = SpotLight(0.0f, 1.0f, 0.0f,		//color
							  0.5f, 0.5f,			//Intensity
							  0.5f, 3.0f, 2.5f,		//postion
							  0.0f, -1.0f, 0.0f,	//direction
							  1.0f, 0.0f, 0.0f,		//constant / linear / exponent	
							 15.0f);				//edge
	spotLightCount++;

	//sphere
	spotLights[2] = SpotLight(0.0f, 0.0f, 1.0f,		//color
							  0.5f, 0.5f,			//Intensity
							  -4.0f, .2f, 3.0f,		//postion
							  0.0f, 0.0f, -1.0f,	//direction
							  1.0f, 0.0f, 0.0f,		//constant / linear / exponent	
							 20.0f);				//edge
	spotLightCount++;

	GLuint uniformProjection = 0, uniformModel = 0, uniformView = 0, uniformEyePosition = 0,
		uniformSpecularIntensity = 0, uniformShininess = 0;

	// create projection with either perspective or Orthographic matrix
	glm::mat4 projection;

	// Loop until window closed
	while (!mainWindow.getShouldClose())
	{
		if (camera.getOrthoView()) {
			// creates an orthographic view matrix
			projection = glm::ortho(-(GLfloat)mainWindow.getBufferWidth() * 0.01f, (GLfloat)mainWindow.getBufferWidth() * 0.01f, 
				-(GLfloat)mainWindow.getBufferHeight() * 0.01f, (GLfloat)mainWindow.getBufferHeight() * 0.01f, 0.001f, 1000.0f);
		}
		else if (
			!camera.getOrthoView()) {
			projection = glm::perspective(glm::radians(45.0f), (GLfloat)mainWindow.getBufferWidth() /
				(GLfloat)mainWindow.getBufferHeight(), 0.1f, 100.0f);
		}

		GLfloat now = glfwGetTime(); // SDL_GetPerformanceCounter();
		deltaTime = now - lastTime; // (now - lastTime)*1000/SDL_GetPerformanceFrequency();
		lastTime = now;

		// Get + Handle User Input
		glfwPollEvents();

		//get input variables
		camera.keyControl(mainWindow.getsKeys(), deltaTime);
		camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());
		camera.scrollControl(mainWindow.getYChange());
		

		// Clear the window
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		shaderList[0].UseShader();
		uniformModel = shaderList[0].GetModelLocation();
		uniformProjection = shaderList[0].GetProjectionLocation();
		uniformView = shaderList[0].GetViewLocation();
		uniformEyePosition = shaderList[0].GetEyePositionLocation();
		uniformSpecularIntensity = shaderList[0].GetSpecularIntensityLocation();
		uniformShininess = shaderList[0].GetShininessLocation();

		//glm::vec3 lowerLight = camera.getCameraPosition();
		//lowerLight.y -= 0.3f;
		//spotLights[0].SetFlash(lowerLight, camera.getCameraDirection());

		shaderList[0].SetDirectionalLight(&mainLight);
		shaderList[0].SetPointLights(pointLights, pointLightCount);
		shaderList[0].SetSpotLights(spotLights, spotLightCount);

		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
		glUniform3f(uniformEyePosition, camera.getCameraPosition().x, camera.getCameraPosition().y,
			camera.getCameraPosition().z);

		//Candle holder base cube
		glm::mat4 model(1.0f);
		model = glm::translate(model, glm::vec3(6.0f, -1.99f, -4.0f));
		model = glm::scale(model, glm::vec3(1.5f, 2.0f, 1.5f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		redTexture.UseTexture();
		shinyMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[0]->RenderMesh();

		//Candle holder top cube
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(6.0f, -1.5f, -4.0f));
		model = glm::scale(model, glm::vec3(2.0f, 2.0f, 2.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		redGlassTexture.UseTexture();
		shinyMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[1]->RenderMesh();

		// candle
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(6.0f, -1.49f, -4.0f));
		model = glm::scale(model, glm::vec3(0.15f, 0.1f, 0.15f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		candleTexture.UseTexture();
		dullMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[2]->RenderMesh();

		//sphere base
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-6.0f, -1.99f, -2.0f));
		model = glm::scale(model, glm::vec3(1.0f, 0.5f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		plainTexture.UseTexture();
		shinyMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[3]->RenderMesh();

		// cube
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-2.0f, -1.99f, 8.0f));
		model = glm::scale(model, glm::vec3(1.0f, 2.0f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		rainbowTexture.UseTexture();
		shinyMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[4]->RenderMesh();

		// plane (floor)
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, -2.0f, 0.0f));
		//model = glm::scale(model, glm::vec3(0.4f, 0.4f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		floorTexture.UseTexture();
		dullMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[5]->RenderMesh();
		
		// pyramid
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(1.0f, -1.99f, 2.0f));
		model = glm::scale(model, glm::vec3(2.5f, 2.5f, 2.5f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		pyramidTexture.UseTexture();
		shinyMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[6]->RenderMesh();


		//sphere
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-6.0f, 0.0f, -2.0f));
		model = glm::scale(model, glm::vec3(2.0f, 2.0f, 2.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		plainTexture.UseTexture();
		shinyMaterial.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[7]->RenderMesh();

		glUseProgram(0);

		mainWindow.swapBuffers();
	}
	return 0;
}
