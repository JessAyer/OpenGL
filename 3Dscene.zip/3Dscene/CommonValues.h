#pragma once

const int MAX_POINT_LIGHTS = 10;
const int MAX_SPOT_LIGHTS = 10;